const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];    
var comlete12 = '';
var dateOfMonth = '';
var array = [];
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

app.get('/', function(request,response){
    response.sendFile(path.join(__dirname + '/public/9.2.html'));
});

app.post('/survey', function(req,res){
   
	dateOfMonth = months[req.body.monthofbirth-1];
    
		if(req.body.completeyear12 == 1){
		comlete12 = 'Before 2010';
		}else if(req.body.completeyear12 == 2){
		comlete12 = 'After 2010';
		}else {
		comlete12 = 'Never';
		}
		
		if(req.body.cometodeakin1){array.push(req.body.cometodeakin1);}
		if(req.body.cometodeakin2){array.push(req.body.cometodeakin2);}
		if(req.body.cometodeakin3){array.push(req.body.cometodeakin3);}
		if(req.body.cometodeakin4){array.push(req.body.cometodeakin4);}
		if(req.body.cometodeakin5){array.push(req.body.cometodeakin5);}
		if(req.body.cometodeakin6){array.push(req.body.cometodeakin6);}
	
		
   res.send('<body style="background:#40e0d0;font-family: Verdana"><span style="color:red;"><h2><b>Thank you for completing our Online Survey</b></h2><p>You were born on the <b>'+req.body.dayofbirth+'</b> of <b>'+dateOfMonth+'</b> in <b>'+req.body.yearofbirth+'</b>.</p><p>Your postcode is: <b>'+req.body.postcode+'</b></p><p>Your gender is: <b>'+req.body.gender+'</b></p><p>You started your primary school in: <b>'+req.body.startprimary+'</b></p><p>You completed year 12: <b>'+comlete12+'</b></p><p>You currently employed full-time: <b>'+req.body.fulltime+'</b></p><p>You currently employed part-time: <b>'+req.body.parttime+'</b></p><p>You come to Deakin from the idea of: <b>'+array.join(',')+'</b></p><p style="font-weight: bold;">Congratulations!</p></span></body>');
   res.end(); 
});

app.listen(3000,function(){
    console.log('server listening to 3000');
});