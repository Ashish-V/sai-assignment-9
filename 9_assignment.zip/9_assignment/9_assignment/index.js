const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

app.get('/', function(request,response){
    response.sendFile(path.join(__dirname + '/public/9.1.html'));
});

app.post('/users', function(req,res){
    res.send('<span><h2><b>Thank you for completing our Online Survey</b></h2> <h3>Your user name is: <b><span style="font-weight : normal">'+req.body.name+'</span></b></h3> <h3><b>Your password is:</b><span style="font-weight : normal"> '+req.body.password+'</span></h3> <h3><b>Your comments are:</b><span style="font-weight : normal"> '+req.body.comment+'</span></h3> <h3><b>Your option is:</b><span style="font-weight : normal"> '+req.body.optradio+'</span></h3> <p style="color:blue;">Congratulations!</p>');
   res.end(); 
});

app.listen(3000,function(){
    console.log('server listening to 3000');
});