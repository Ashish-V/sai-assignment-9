const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('myDB');

db.serialize(function() {
    
db.run("CREATE TABLE IF NOT EXISTS Userdetails (name TEXT, password TEXT, option TEXT)");
console.log("Database created");

});

module.exports=db;