const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
app.set('view engine', 'pug')
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

app.get('/', function(request,response){
    response.sendFile(path.join(__dirname + '/public/9.2.html'));
});

app.post('/survey', function(req,res){
    console.log(req.body);
    //res.render('index', { title: 'Hey', message: 'Hello there!' });
    //res.send('<h2><b>Thank you for completing our Online Survey</b></h2><br><h3><b>Your username is:</b><span style="font-weight : normal"> '+req.body.name+'</span></h3><br><h3><b>Your password is:</b><span style="font-weight : normal"> '+req.body.password+'</span></h3><br><h3><b>Your comments are:</b><span style="font-weight : normal"> '+req.body.comment+'</span></h3><br><h3><b>Your option is:</b><span style="font-weight : normal"> '+req.body.optradio+'</span></h3><br><p style="color:blue;">Congratulation!</p>');
   res.end(); 
});

app.listen(3000,function(){
    console.log('server listening to 3000');
});