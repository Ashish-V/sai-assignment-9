const express = require('express')
const bodyParser = require("body-parser");
const path = require('path');
const port = 3000;
const app = express();
const sqlite3 = require('sqlite3').verbose();

// persistant file database "myDB".
const db = new sqlite3.Database('myDB');

db.serialize(function() {
    
db.run("CREATE TABLE IF NOT EXISTS Userdetails (name TEXT, password TEXT, option TEXT)");

});

 app.use(express.static('public_html'));

app.use(bodyParser.urlencoded({ extended: false }));

app.post('/users', function (req, res, next) {

    const stmt = db.run(`INSERT INTO Userdetails VALUES ("${req.body.name}", "${req.body.password}", "${req.body.optradio}")`);
    db.each("SELECT * FROM Userdetails", function(err, row) {
        console.log("Data entered into Database"); 
    });

    res.status(200).redirect('/');  
});

app.get('/users', function (req, res) {
  
    res.write('<body>');
    res.write("<h3> The response table </h3>");
    res.write("<table><tr style='background-color:whitesmoke'>");
    res.write('<th width="250" style="color:whitesmoke;background-color:black">Name</th>');
    res.write('<th width="250" style="color:whitesmoke;background-color:black">Password</th>');
    res.write('<th width="250" style="color:whitesmoke;background-color:black">Option</th><tr>');

    // Retrieve data from table Userdetails on the server 
    // and display it in a web page table structure
    db.all('SELECT * FROM Userdetails', function(err, rows){
        rows.forEach(function (row){
            res.write('<tr style="background-color:whitesmoke">');
            res.write('<td width="200" align="center">'+row.name+'</td>');
            res.write('<td width="200" align="center">'+row.password+'</td>');
            res.write('<td width="200" align="center">'+row.option+'</td></tr>');
        });
        res.write('</table>');
        res.write('</body>');
        res.send();
    });

});

// create a Node.js server that listens on port 3000.
app.listen(port, function () {
console.log('server listening to '+port);
})